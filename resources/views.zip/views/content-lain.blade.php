@extends('navbar')
@section('content')
@parent
<div class="row">
    <div class="col-lg-12 text-center">
        <h1 class="mt-5">Konten yang berbeda</h1>
        <p class="lead">Ini bukan Lending!</p>
        <ul class="list-unstyled">
            <li>ehehehe 4.5.3</li>
            <li>heheheh 3.5.1</li>
        </ul>
    </div>
</div>
@endsection